# Verification record

| Check | Result | Evidence |
|---|---|---|
| PC1 to .12 | 4 replies, 0% loss | Pasted ping output in lesson |
| PC1 to .13 | 4 replies, 0% loss | ping-and-arp.png |
| PC1 to .14 | 4 replies, 0% loss | Learner report |
| PC1 to .1 after fix | Successful | Learner report |
| Router G0/0 | 192.168.10.1, up/up | router-interfaces.png |
| ARP | .12 and .13 mapped to MAC addresses | ping-and-arp.png |
| Switch learning | PC1, PC2, PC3 and router learned | switch-mac-table.png |
| Routing | C /24 and L /32 | Pasted show ip route output |
| Switch enable secret test | Returned to S1-Office# after password | Pasted CLI output |

## Repeat checks
On PC1: ping 192.168.10.12, .13, .14 and .1 separately, then run arp -a.
On router: show ip interface brief; show ip route; show running-config.
On switch immediately after traffic: show mac address-table; show running-config.

Expected routes:
```
C 192.168.10.0/24 is directly connected, GigabitEthernet0/0
L 192.168.10.1/32 is directly connected, GigabitEthernet0/0
```
No gateway of last resort is expected. Dynamic ARP/MAC entries can age out.

# Configuration evidence and final export task

The router and switch configurations were reviewed from CLI text supplied in the lesson. These notes are not complete configuration exports and should not be pasted as a full replacement configuration.

Router settings verified:
```
hostname R1-Office
interface GigabitEthernet0/0
 description connected on S1-Office F0/5
 ip address 192.168.10.1 255.255.255.0
```
G0/0 was operational; unused G0/1 and G0/2 were shut down. An enable secret was present.

Switch settings verified:
```
hostname S1-Office
interface FastEthernet0/5
 description connected to R1-Office G0/0
```
The original switch export had no enable secret. It was subsequently added and a successful password test was supplied. A new full export is still needed.

## Export final configurations
At each device's privileged # prompt, run show running-config. Copy the complete output through end into R1-Office-config.txt and S1-Office-config.txt. Save each device using copy running-config startup-config, then save the Packet Tracer project.

The router rejected show interfaces description in this Packet Tracer session; show running-config was used instead.

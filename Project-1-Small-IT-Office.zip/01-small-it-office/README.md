# Small IT Office — Cisco Packet Tracer

A beginner network simulation by Hisan Moosa.

## Overview and business scenario
Four office computers need local connectivity. I built a network with a Cisco 2911 router, a Cisco 2960-24TT switch and four PCs. I used static IPv4 addresses and tested communication with ping.

This is a learning simulation. It does not provide internet access or represent a production deployment.

## Objectives
- Connect four PCs through one switch.
- Configure a router interface as the office gateway.
- Verify local connectivity and read MAC, ARP and routing tables.
- Name devices, label the router-switch link, configure enable secrets and save settings.
- Investigate faults and record the evidence.

## Topology
![Office topology](topology/topology.png)

The supplied topology screenshot uses PC0–PC3 display names. This documentation uses address-based logical names PC1–PC4. Check IP addresses when matching screenshots to devices; updated display names have not been verified.

| Connection | Switch port |
|---|---|
| PC1 (.11) | Fa0/1 |
| PC2 (.12) | Fa0/2 |
| PC3 (.13) | Fa0/3 |
| PC4 (.14), planned connection | Fa0/4 |
| R1-Office G0/0 | Fa0/5 |

PC1–PC3 and the router port mappings are supported by the supplied MAC-table evidence. PC4's mapping follows the lab plan and should be checked against the saved file.

## Technologies
Ethernet, default VLAN 1, static IPv4, ICMP ping, ARP, dynamic MAC learning, connected/local routes and basic Cisco IOS administration.

## Addressing and routing
See [addressing table](addressing/ip-addressing.md). The router has a connected route for 192.168.10.0/24 and a local route for 192.168.10.1/32. No default route is configured. Same-subnet PC traffic is switched directly without passing through the router.

## Configuration
Router hostname: R1-Office. Switch hostname: S1-Office. Both devices have enable secrets, based on configuration output and the later successful switch password test. The router G0/0 and switch Fa0/5 have connection descriptions.

See [configuration notes](configurations/configuration-notes.md). Complete exported configurations are not included yet. The uploaded binary Packet Tracer file is retained unchanged.

## Verification and testing
See [test results](verification/test-results.md) and the screenshots in that folder. Evidence includes successful ping to .13, ARP mappings, router G0/0 up/up and dynamically learned switch entries. Other successful pings were reported during the lesson rather than captured individually.

## Troubleshooting
See [incident report](troubleshooting/incident-report.md). The router interface was initially disabled; enabling it restored ping. A separate wrong-IP scenario was a guided discussion, not a fault verified in the saved file.

## Security and limitations
Enable secrets protect privileged-mode entry. They do not by themselves secure console login, enable SSH or control user traffic. This lab has no configured SSH, ACLs, DHCP, NAT, custom VLAN segmentation or backup path. Practice credentials are not suitable for real equipment.

The screenshots show Packet Tracer's earlier state. The .pkt file has not been independently opened or executed during documentation preparation. Configuration evidence comes from the learner's pasted CLI output and screenshots.

## Lessons learned
- Learn MAC addresses from incoming source MACs; forward using destination MACs.
- Unknown unicast frames are flooded through other forwarding ports in the same VLAN.
- ARP maps an IPv4 address to a MAC address; a switch MAC table maps a MAC to a port.
- A gateway is needed for other subnets, not ordinary same-subnet communication.
- C marks a connected network; L marks the router's own address.
- Save device configurations and also save the Packet Tracer file.

## Design choices and future improvements
One switch is enough for this small practice network. It is also a single point of failure. Static addressing is easy to inspect with four PCs but requires manual work as the office grows. Later projects will introduce routing between networks, DHCP, segmentation and secure remote management.

## Open the lab
Open [small-it-office.pkt](topology/small-it-office.pkt) in Cisco Packet Tracer. Use the addressing table and verification checklist to retest it.

## Remaining portfolio work
- Confirm PC labels and PC4's physical port; update the topology screenshot if needed.
- Export complete final router and switch running configurations.
- Complete the short interview review in documentation/next-steps.md.
- Create a GitHub repository and upload these files when ready. No repository has been created or published as part of this package.

# Incident 1 — Router did not reply to ping

Type: fault observed during the learner's lab.

Symptom: PC1 could ping PC2, but ping to 192.168.10.1 timed out four times.
Investigation: checked the router's G0/0 address, mask, port status and cable connection.
Root cause: the router port was not enabled, as confirmed by the learner.
Fix: enabled Port Status; the IOS equivalent is no shutdown under interface g0/0.
Retest: the learner reported successful replies. Later interface output showed G0/0 up/up.
Lesson: a correct IP address alone does not enable an interface.

# Scenario 2 — PC3 had an incorrect IP

Type: imaginary troubleshooting exercise; not an injected fault in the uploaded file.

Symptoms supplied: PC3 could not communicate; other PCs worked; PC3's cable and link were good.
Evidence supplied: PC3 had 192.168.20.13/24 instead of the intended 192.168.10.13/24.
Learner diagnosis: the third octet did not match the office /24 network.
Proposed fix: use 192.168.10.13 with mask 255.255.255.0.
Proposed verification: ping the other PCs and gateway from PC3.
Lesson: check addressing after physical connectivity; the gateway does not handle normal same-subnet PC traffic.

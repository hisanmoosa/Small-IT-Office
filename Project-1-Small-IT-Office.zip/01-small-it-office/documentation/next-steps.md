# Project close-out

## Evidence still needed
1. Confirm the logical PC names against their configured IP addresses.
2. Confirm PC4 uses switch Fa0/4.
3. Export the final full router and switch configurations.
4. Retest after reopening the saved .pkt file.

## Interview review — answer before reading model answers
1. Explain your office network in 3–4 sentences.
2. Why did you include a router if same-subnet PCs can communicate without it?
3. How did you find and fix the gateway connectivity fault?
4. What is the difference between an ARP table and a switch MAC table?
5. What would stop working if the switch failed?

## GitHub preparation
Create a repository named small-it-office-packet-tracer. Upload this folder's contents, keeping the file structure. Do not claim production deployment. No GitHub actions have been performed yet.

Suggested commits, only as the corresponding work is actually added:
- Add office topology and addressing plan
- Add verified device configurations
- Document connectivity tests and troubleshooting

## CV wording supported by current evidence
Small IT Office Network — Cisco Packet Tracer
- Built a simulated four-PC LAN using a Cisco router and switch with static IPv4 addressing.
- Verified connectivity using ping, ARP, MAC address tables and router interface status.
- Resolved a disabled router-interface fault and configured device hostnames, interface descriptions and privileged-access passwords.

These describe a simulation, not employment or production experience.

# IP addressing

| Device (logical name) | Interface | IP address | Mask | Gateway |
|---|---|---|---|---|
| R1-Office | G0/0 | 192.168.10.1 | 255.255.255.0 | Not configured |
| PC1 | FastEthernet0 | 192.168.10.11 | 255.255.255.0 | 192.168.10.1 |
| PC2 | FastEthernet0 | 192.168.10.12 | 255.255.255.0 | 192.168.10.1 |
| PC3 | FastEthernet0 | 192.168.10.13 | 255.255.255.0 | 192.168.10.1 |
| PC4 | FastEthernet0 | 192.168.10.14 | 255.255.255.0 | 192.168.10.1 |
| S1-Office | VLAN 1 SVI | Unassigned | N/A | Not configured |

The PC rows reflect the lesson's address plan and reported connectivity. Individual PC configuration screenshots are not included. DNS is not needed for these IP-based tests.

Network: 192.168.10.0/24. Usable range: .1–.254. Broadcast: 192.168.10.255.
All switch connections use default VLAN 1; no custom VLANs were configured.
